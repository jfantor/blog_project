// $(document).ready(function(){
//     var mixer = mixitup(".box-list");
// });
