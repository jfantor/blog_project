// gsap.registerPlugin(ScrollTrigger);

// gsap.to(".square",{

//     // x: 400,
//     duration:8,
//     scrollTrigger: {
//         trigger: '.square2',
//         start: "top 80%",
//         end: "top 30%",
//         toggleActions:"restart none none none",
//         scrub:4,
//         pin: ".square",
//         pinSpacing: true,

//         markers: true

//     }

// });
// const tl = gsap.timeline({
//     scrollTrigger:{
//         trigger: ".box",
        
//         start:"top 80%",
//         end:"top 30%",
//         scrub:true,

//         markers:true
//     }
// });
// tl.to(".box", {x:300, duration:2})
//   .to(".box", {y:300, duration:2})
//   .to(".box", {x:0, duration:2})
//   .to(".box", {y:0, duration:2})

// ScrollTrigger.create({
//     trigger:".box",
//     start:"top 80%",
//     end:"top 50%",
//     markers:true,
//     toggleClass:"red-box"
// })


// ScrollTrigger.create({
//     markers:true,
//     start:"top 10%",
//     trigger:".div1",
//     toggleClass:{
//         targets:"nav",
//         className:"nav-active"
//     }
// })

// ScrollTrigger.create({
//     markers:true,
//     start:"top 80%",
//     end:"top 50%",
//     trigger:".box",
//     // onUpdate:(self) => console.log(self)
//     // onEnter: ()=> console.log("enter!"),
//     // onLeave:() => console.log("leave!"),
//     // onEnterBack: () => console.log("enterBack"),
//     // onLeaveBack: () => console.log("leave back")
// })
gsap.registerPlugin(ScrollTrigger);


// =======================================
//===============skill bar animation================
// ======================================
gsap.from(".bar abbr", {
  scrollTrigger:{
    trigger: ".bar",
    toggleActions: "restart none restart none",
  },
  left:0,
  ease:Power2.easeInOut,
  duration:3,
  stagger:0.1
 
});
gsap.from(".bar span", {
  scrollTrigger:{
    trigger: ".bar",
    toggleActions: "restart none restart none",
  },
  width:"0%",
  ease: Power2.easeInOut,
  duration:3,
  stagger:0.1
  
});
// =======================================
//===============right animation================
// ======================================
gsap.from(".animation01", {
  scrollTrigger:{
    trigger: ".animation01",
    toggleActions: "restart none restart none"
    
  },
  x:-600,
  ease:Power2.easeInOut,
  duration:1,
  opacity:0,
  stagger:0.1
 
});

gsap.from(".animation0", {
  scrollTrigger:{
    trigger: ".animation0",
    toggleActions: "restart none restart none"
    
  },
  x:-600,
  ease:Power2.easeInOut,
  duration:1,
  opacity:0,
  stagger:0.1
 
});

gsap.from(".animation", {
  scrollTrigger:{
    trigger: ".animation",
    toggleActions: "restart none restart none"
    
  },
  x:-600,
  ease:Power2.easeInOut,
  duration:1,
  opacity:0,
  stagger:0.1
 
});
gsap.from(".animation2", {
  scrollTrigger:{
    trigger: ".animation2",
    toggleActions: "restart none restart none"
    
  },
  x:-600,
  ease:Power2.easeInOut,
  duration:1,
  opacity:0,
  stagger:0.1
 
});
gsap.from(".animation3", {
  scrollTrigger:{
    trigger: ".animation3",
    toggleActions: "restart none restart none"
   
  },
  x:-600,
  ease:Power2.easeInOut,
  duration:1,
  opacity:0,
  stagger:0.1
 
});
gsap.from(".animation4", {
  scrollTrigger:{
    trigger: ".animation4",
    toggleActions: "restart none restart none"
   
  },
  x:-600,
  ease:Power2.easeInOut,
  duration:1,
  opacity:0,
  stagger:0.1
 
});
gsap.from(".animation-f-5", {
  scrollTrigger:{
    trigger: ".animation-f-5",
    toggleActions: "restart none restart none"
   
  },
  x:-600,
  ease:Power2.easeInOut,
  duration:1,
  opacity:0,
  stagger:0.1
 
});
// =======================================
//===============right animation================
// ======================================
gsap.from(".animation-right-1", {
  scrollTrigger:{
    trigger: ".animation-f-5",
    toggleActions: "restart none restart none"
   
  },
  x:600,
  ease:Power2.easeInOut,
  duration:1,
  opacity:0,
  stagger:0.1
 
});
gsap.from(".animation-right-0", {
  scrollTrigger:{
    trigger: ".animation-right-0",
    toggleActions: "restart none restart none"
   
  },
  x:600,
  ease:Power2.easeInOut,
  duration:1,
  opacity:0,
  stagger:0.1
 
});
// =======================================
//===============bottom animation================
// ======================================
gsap.from(".animation-bottom-0", {
  scrollTrigger:{
    trigger: ".animation0",
    toggleActions: "restart none restart none"
   
  },
  y:600,
  ease:Power2.easeInOut,
  duration:1,
  opacity:0,
  stagger:0.1
 
});
gsap.from(".animation-bottom-1", {
  scrollTrigger:{
    trigger: ".animation",
    toggleActions: "restart none restart none"
   
  },
  y:600,
  ease:Power2.easeInOut,
  duration:1,
  opacity:0,
  stagger:0.1
 
});
gsap.from(".animation-bottom-2", {
  scrollTrigger:{
    trigger: ".animation2",
    toggleActions: "restart none restart none"
   
  },
  y:600,
  ease:Power2.easeInOut,
  duration:1,
  opacity:0,
  stagger:0.1
 
});
gsap.from(".animation-bottom-3", {
  scrollTrigger:{
    trigger: ".animation3",
    toggleActions: "restart none restart none"
   
  },
  y:600,
  ease:Power2.easeInOut,
  duration:1,
  opacity:0,
  stagger:0.1
 
});
gsap.from(".animation-bottom-4", {
  scrollTrigger:{
    trigger: ".animation4",
    toggleActions: "restart none restart none"
   
  },
  y:600,
  ease:Power2.easeInOut,
  duration:1,
  opacity:0,
  stagger:0.1
 
});

gsap.from(".animation-bottom-5f", {
  scrollTrigger:{
    trigger: ".animation-bottom-5f",
    toggleActions: "restart none restart none"
   
  },
  y:-600,
  ease:Power2.easeInOut,
  duration:1,
  opacity:0,
  stagger:0.1
 
});



$(document).ready(function() {
    var $window = $(window);  
    var $sidebar = $("#site-header"); 
    var $sidebarOffset = $sidebar.offset();
  
    $window.scroll(function() {
      if($window.scrollTop() >=650 &&! $sidebarOffset.top) {
        $sidebar.addClass("sticky");
      } else {
        $sidebar.removeClass("sticky");   
      }    
          
    });   
    var options = {
      animateClass: 'animate__animated', // for v3 or 'animate__animated' for v4
      animateThreshold: 100,
      scrollPollInterval: 20
  }
});